﻿using BookMyShow_DAO;

using Microsoft.AspNetCore.Mvc;

using Microsoft.EntityFrameworkCore;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace BookMyShow_API.Controllers

{

    [Route("api/[controller]")]

    [ApiController]

    public class AdminRegistartionsController : ControllerBase

    {

        private readonly BookMyShowDbContext _context;

        public AdminRegistartionsController(BookMyShowDbContext context)

        {

            _context = context;

        }

        // GET: api/<MoviesController>

        [HttpGet]

        public IEnumerable<AdminRegistartion> GetAdminRegistartions()

        {

            return _context.AdminRegistartions.ToList();

        }

        // GET api/<MoviesController>/5

        [HttpGet("{id}")]

        public AdminRegistartion GetAdminRegistartions(int id)

        {

            var adre = _context.AdminRegistartions.Find(id);

            if (adre == null)

            {

                return new AdminRegistartion();

            }

            return adre;

        }

        // POST api/<MoviesController>

        [HttpPost]

        public void PostAdminRegistartion([FromBody] AdminRegistartion adre)

        {

            _context.AdminRegistartions.Add(adre);

            _context.SaveChanges();

        }

        // PUT api/<MoviesController>/5

        [HttpPut("{id}")]

        public void PutAdminRegistartion(int id, [FromBody] AdminRegistartion adre)

        {

            _context.Entry(adre).State = EntityState.Modified;

            _context.SaveChanges();

        }

        // DELETE api/<MoviesController>/5

        [HttpDelete("{id}")]

        public bool DeleteAdminRegistartion(int id)

        {

            var adre = _context.AdminRegistartions.Find(id);

            if (adre == null)

            {

                return false;

            }

            _context.AdminRegistartions.Remove(adre)  ;

            _context.SaveChanges();

            return true;

        }

    }

}