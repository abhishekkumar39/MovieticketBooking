﻿using BookMyShow_DAO;

using Microsoft.AspNetCore.Mvc;

using Microsoft.EntityFrameworkCore;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace BookMyShow_API.Controllers

{

    [Route("api/[controller]")]

    [ApiController]

    public class AdminsController : ControllerBase

    {

        private readonly BookMyShowDbContext _context;

        public AdminsController(BookMyShowDbContext context)

        {

            _context = context;

        }

        // GET: api/<MoviesController>

        [HttpGet]

        public IEnumerable<Admin> GetAdmins()

        {

            return _context.Admins.ToList();

        }

        // GET api/<MoviesController>/5

        [HttpGet("{id}")]

        public Admin GetAdmins(int id)

        {

            var ad = _context.Admins.Find(id);

            if (ad == null)

            {

                return new Admin();

            }

            return ad;

        }

        // POST api/<MoviesController>

        [HttpPost]

        public void PostAdmin([FromBody] Admin ad)

        {

            _context.Admins.Add(ad);

            _context.SaveChanges();

        }

        // PUT api/<MoviesController>/5

        [HttpPut("{id}")]

        public void PutAdmin(int id, [FromBody] Admin ad)

        {

            _context.Entry(ad).State = EntityState.Modified;

            _context.SaveChanges();

        }

        // DELETE api/<MoviesController>/5

        [HttpDelete("{id}")]

        public bool DeleteAdmin(int id)

        {

            var ad = _context.Admins.Find(id);

            if (ad == null)

            {

                return false;

            }

            _context.Admins.Remove(ad);

            _context.SaveChanges();

            return true;

        }

    }

}