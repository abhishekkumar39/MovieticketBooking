﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BookMyShow_DAO;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace BookMyShow_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookingsController : ControllerBase
    {
        private readonly BookMyShowDbContext _context;
        public BookingsController(BookMyShowDbContext context)
        {
            _context = context;
        }
        // GET: api/<MoviesController>
        [HttpGet]
        public IEnumerable<Booking> GetBookings()
        {
            return _context.Bookings.ToList();
        }

        // GET api/<MoviesController>/5
        [HttpGet("{id}")]
        public Booking GetBooking(int id)
        {
            var book = _context.Bookings.Find(id);

            if (book == null)
            {
                return new Booking();
            }
            return book;
        }

        // POST api/<MoviesController>
        [HttpPost]
        public void PostBooking([FromBody] Booking book)
        {
            _context.Bookings.Add(book);
            _context.SaveChanges();
        }

        // PUT api/<MoviesController>/5
        [HttpPut("{id}")]
        public void PutBooking(int id, [FromBody] Booking book)
        {
            _context.Entry(book).State = EntityState.Modified;
            _context.SaveChanges();
        }

        // DELETE api/<MoviesController>/5
        [HttpDelete("{id}")]
        public bool DeleteBooking(int id)
        {
            var book = _context.Bookings.Find(id);
            if (book == null)
            {
                return false;
            }

            _context.Bookings.Remove(book);
            _context.SaveChanges();
            return true;
        }
    }
}
