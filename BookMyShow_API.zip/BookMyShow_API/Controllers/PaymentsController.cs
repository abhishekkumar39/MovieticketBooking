﻿using BookMyShow_DAO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace BookMyShow_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PaymentsController : ControllerBase
    {
        private readonly BookMyShowDbContext _context;
        public PaymentsController(BookMyShowDbContext context)
        {
            _context = context;
        }
        // GET: api/<PaymentsController>
        [HttpGet]
        public IEnumerable<Payment> GetPAyments()
        {
            return _context.Payments.ToList();
        }

        // GET api/<PaymentsController>/5
        [HttpGet("{id}")]
        public Payment GetPayment(int id)
        {
            var pay = _context.Payments.Find(id);

            if (pay == null)
            {
                return new Payment();
            }
            return pay;
        }

        // POST api/<PaymentsController>
        [HttpPost]
        public void PostPayment([FromBody] Payment pay)
        {
            _context.Payments.Add(pay);
            _context.SaveChanges();
        }

        // PUT api/<PAymentsController>/5
        [HttpPut("{id}")]
        public void PutPayment(int id, [FromBody] Payment pay)
        {
            _context.Entry(pay).State = EntityState.Modified;
            _context.SaveChanges();
        }

        // DELETE api/<PaymentsController>/5
        [HttpDelete("{id}")]
        public bool DeletePayment(int id)
        {
            var pay = _context.Payments.Find(id);
            if (pay == null)
            {
                return false;
            }

            _context.Payments.Remove(pay);
            _context.SaveChanges();
            return true;
        }
    }
}