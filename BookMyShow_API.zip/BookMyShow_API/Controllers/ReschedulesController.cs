﻿using BookMyShow_DAO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace BookMyShow_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReschedulesController : ControllerBase
    {
        private readonly BookMyShowDbContext _context;
        public ReschedulesController(BookMyShowDbContext context)
        {
            _context = context;
        }
        // GET: api/<ReschedulesController>
        [HttpGet]
        public IEnumerable<Reschedule> GetReschedules()
        {
            return _context.Reschedules.ToList();
        }

        // GET api/<ReschedulesController>/5
        [HttpGet("{id}")]
        public Reschedule GetReschedule(int id)
        {
            var res = _context.Reschedules.Find(id);

            if (res == null)
            {
                return new Reschedule();
            }
            return res;
        }

        // POST api/<ReschedulesController>
        [HttpPost]
        public void PostReschedule([FromBody] Reschedule res)
        {
            _context.Reschedules.Add(res);
            _context.SaveChanges();
        }

        // PUT api/<ReschedulesController>/5
        [HttpPut("{id}")]
        public void PutReschedule(int id, [FromBody] Reschedule res)
        {
            _context.Entry(res).State = EntityState.Modified;
            _context.SaveChanges();
        }

        // DELETE api/<ReschedulesController>/5
        [HttpDelete("{id}")]
        public bool DeleteReschedule(int id)
        {
            var res = _context.Reschedules.Find(id);
            if (res == null)
            {
                return false;
            }

            _context.Reschedules.Remove(res);
            _context.SaveChanges();
            return true;
        }
    }
}