﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookMyShow_DAO
{
    public class AdminRegistartion
    {
        public int AdminRegistartionId { get; set; }
        public string? AdminName { get; set; }
        public string? AdminPassword { get; set; }
        public string? ConfirmPassword { get; set; }
        public string? AdminEmail { get; set; }
        public string? AdminCity { get; set; }
        public string? AdminState { get; set; }
        public string? AdminCountry { get; set; }
        public string? AdminPincode { get; set; }



    }
}
