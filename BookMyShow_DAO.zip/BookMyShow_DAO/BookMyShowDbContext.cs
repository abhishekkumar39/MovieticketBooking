﻿using Microsoft.EntityFrameworkCore;
using System.Net.Sockets;

namespace BookMyShow_DAO
{
    public class BookMyShowDbContext:DbContext
    {
        public BookMyShowDbContext(DbContextOptions<BookMyShowDbContext> options) : base(options)
        {
            this.Database.EnsureCreated();
        }
        public DbSet<AdminRegistartion> AdminRegistartions { get; set; }
        public DbSet<Movie> Movies { get; set; }
        public DbSet<Theater> Theaters { get; set; }
        public DbSet<UserRegistration> UserRegistrations { get; set; }
        public DbSet<UserLogin> UserLogins { get; set; }
        public DbSet<Admin> Admins { get; set; }
        public DbSet<Booking> Bookings { get; set; }
        public DbSet<Cancellation> Cancellations { get; set; }
        public DbSet<Reschedule> Reschedules { get; set; }
        public DbSet<Payment> Payments { get; set; }

        public DbSet<Feedback> Feedbacks { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }
    }
}
