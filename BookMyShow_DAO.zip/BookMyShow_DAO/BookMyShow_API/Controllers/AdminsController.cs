﻿using BookMyShow_DAO;

using Microsoft.AspNetCore.Mvc;

using Microsoft.EntityFrameworkCore;


namespace BookMyShow_API.Controllers

{

    [Route("api/[controller]")]

    [ApiController]

    public class AdminsController : ControllerBase

    {

        private readonly BookMyShowDbContext _context;

        public AdminsController(BookMyShowDbContext context)

        {

            _context = context;

        }


        [HttpGet]

        public IEnumerable<Admin> GetAdmins()

        {

            return _context.Admins.ToList();

        }


        [HttpGet("{id}")]

        public Admin GetAdmins(int id)

        {

            var rest = _context.Admins.Find(id);

            if (rest == null)

            {

                return new Admin();

            }

            return rest;

        }



        [HttpPost]

        public void PostAdmins([FromBody] Admin rest)

        {

            _context.Admins.Add(rest);

            _context.SaveChanges();

        }



        [HttpPut("{id}")]

        public void PutAdmins(int id, [FromBody] Admin rest)

        {

            _context.Entry(rest).State = EntityState.Modified;

            _context.SaveChanges();

        }



        [HttpDelete("{id}")]

        public bool DeleteAdmins(int id)

        {

            var rest = _context.Admins.Find(id);

            if (rest == null)

            {

                return false;

            }

            _context.Admins.Remove(rest);

            _context.SaveChanges();

            return true;

        }

    }

}