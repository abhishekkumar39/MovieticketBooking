﻿using BookMyShow_DAO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace BookMyShow_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MoviesController : ControllerBase
    {
        private readonly BookMyShowDbContext _context;
        public MoviesController(BookMyShowDbContext context)
        {
            _context = context;
        }
        // GET: api/<MoviesController>
        [HttpGet]
        public IEnumerable<Movie> GetMovies()
        {
            return _context.Movies.ToList();
        }

        // GET api/<MoviesController>/5
        [HttpGet("{id}")]
        public Movie GetMovies(int id)
        {
            var rest = _context.Movies.Find(id);

            if (rest == null)
            {
                return new Movie();
            }
            return rest;
        }

        // POST api/<MoviesController>
        [HttpPost]
        public void PostMovie([FromBody] Movie rest)
        {
            _context.Movies.Add(rest);
            _context.SaveChanges();
        }

        // PUT api/<MoviesController>/5
        [HttpPut("{id}")]
        public void PutMovie(int id, [FromBody] Movie rest)
        {
            _context.Entry(rest).State = EntityState.Modified;
            _context.SaveChanges();
        }

        // DELETE api/<MoviesController>/5
        [HttpDelete("{id}")]
        public bool DeleteMovie(int id)
        {
            var rest = _context.Movies.Find(id);
            if (rest == null)
            {
                return false;
            }

            _context.Movies.Remove(rest);
            _context.SaveChanges();
            return true;
        }
    }
}