﻿using BookMyShow_DAO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace BookMyShow_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReschedulesController : ControllerBase
    {
        private readonly BookMyShowDbContext _context;
        public ReschedulesController(BookMyShowDbContext context)
        {
            _context = context;
        }
        // GET: api/<ReschedulesController>
        [HttpGet]
        public IEnumerable<Reschedule> GetReschedules()
        {
            return _context.Reschedules.ToList();
        }

        // GET api/<ReschedulesController>/5
        [HttpGet("{id}")]
        public Reschedule GetReschedules(int id)
        {
            var ul = _context.Reschedules.Find(id);

            if (ul == null)
            {
                return new Reschedule();
            }
            return ul;
        }

        // POST api/<ReschedulesController>
        [HttpPost]
        public void PostReschedule([FromBody] Reschedule ul)
        {
            _context.Reschedules.Add(ul);
            _context.SaveChanges();
        }

        // PUT api/<ReschedulesController>/5
        [HttpPut("{id}")]
        public void PutReschedule(int id, [FromBody] Reschedule ul)
        {
            _context.Entry(ul).State = EntityState.Modified;
            _context.SaveChanges();
        }

        // DELETE api/<ReschedulesController>/5
        [HttpDelete("{id}")]
        public bool DeleteReschedule(int id)
        {
            var ul = _context.Reschedules.Find(id);
            if (ul == null)
            {
                return false;
            }

            _context.Reschedules.Remove(ul);
            _context.SaveChanges();
            return true;
        }
    }
}