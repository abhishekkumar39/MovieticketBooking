﻿using BookMyShow_DAO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace BookMyShow_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserLoginsController : ControllerBase
    {
        private readonly BookMyShowDbContext _context;
        public UserLoginsController(BookMyShowDbContext context)
        {
            _context = context;
        }
        // GET: api/<MoviesController>
        [HttpGet]
        public IEnumerable<UserLogin> GetUserLogins()
        {
            return _context.UserLogins.ToList();
        }

        // GET api/<MoviesController>/5
        [HttpGet("{id}")]
        public UserLogin GetUserLogins(int id)
        {
            var ul = _context.UserLogins.Find(id);

            if (ul == null)
            {
                return new UserLogin();
            }
            return ul;
        }

        // POST api/<MoviesController>
        [HttpPost]
        public void PostUserLogin([FromBody] UserLogin ul)
        {
            _context.UserLogins.Add(ul);
            _context.SaveChanges();
        }

        // PUT api/<MoviesController>/5
        [HttpPut("{id}")]
        public void PutUserLogin(int id, [FromBody] UserLogin ul)
        {
            _context.Entry(ul).State = EntityState.Modified;
            _context.SaveChanges();
        }

        // DELETE api/<MoviesController>/5
        [HttpDelete("{id}")]
        public bool DeleteUserLogin(int id)
        {
            var ul = _context.UserLogins.Find(id);
            if (ul == null)
            {
                return false;
            }

            _context.UserLogins.Remove(ul);
            _context.SaveChanges();
            return true;
        }
    }
}