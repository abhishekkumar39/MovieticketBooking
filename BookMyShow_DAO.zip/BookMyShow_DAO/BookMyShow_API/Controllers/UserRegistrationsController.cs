﻿using BookMyShow_DAO;

using Microsoft.AspNetCore.Mvc;

using Microsoft.EntityFrameworkCore;


namespace BookMyShow_API.Controllers

{

    [Route("api/[controller]")]

    [ApiController]

    public class UserRegistrationsController : ControllerBase

    {

        private readonly BookMyShowDbContext _context;

        public UserRegistrationsController(BookMyShowDbContext context)

        {

            _context = context;

        }


        [HttpGet]

        public IEnumerable<UserRegistration> GetUserRegistrations()

        {

            return _context.UserRegistrations.ToList();

        }


        [HttpGet("{id}")]

        public UserRegistration GetUserRegistrations(int id)

        {

            var rest = _context.UserRegistrations.Find(id);

            if (rest == null)

            {

                return new UserRegistration();

            }

            return rest;

        }


        [HttpPost]

        public void PostUserRegistrations([FromBody] UserRegistration rest)

        {

            _context.UserRegistrations.Add(rest);

            _context.SaveChanges();

        }


        [HttpPut("{id}")]

        public void PutUserRegistrations(int id, [FromBody] UserRegistration rest)

        {

            _context.Entry(rest).State = EntityState.Modified;

            _context.SaveChanges();

        }


        [HttpDelete("{id}")]

        public bool DeleteUserRegistrations(int id)

        {

            var rest = _context.UserRegistrations.Find(id);

            if (rest == null)

            {

                return false;

            }

            _context.UserRegistrations.Remove(rest);

            _context.SaveChanges();

            return true;

        }

    }

}