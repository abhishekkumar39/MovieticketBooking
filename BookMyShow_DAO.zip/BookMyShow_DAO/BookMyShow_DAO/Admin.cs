﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookMyShow_DAO
{

    public class Admin
    {
        [Required(ErrorMessage = "AdminId is required.")]
        public int AdminId { get; set; }
        public string? AdminName { get; set; }

        [Required(ErrorMessage = "Password is required.")]
        [DataType(DataType.Password)]
        public string? AdminPassword { get; set; }

    }
}
