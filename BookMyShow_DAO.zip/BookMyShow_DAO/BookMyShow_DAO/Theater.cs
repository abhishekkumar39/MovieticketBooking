﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookMyShow_DAO
{
    public class Theater
    {
        public int TheaterId { get; set; }
        public string? TheaterName { get; set; }
        public string? TheaterLocation { get; set; }
        public string? TheaterCapacity { get; set; }
        public string? SeatType { get; set; }
        public int unitPrice { get; set; }

    }
}