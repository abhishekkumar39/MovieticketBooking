﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookMyShow_DAO
{

    public class UserLogin
    {
        public int UserLoginId { get; set; }
        public int UserRegistrationId { get; set; }
        [Required(ErrorMessage = "Password is required.")]
        [DataType(DataType.Password)]
        public string? UserPassword { get; set; }

    }
}