﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookMyShow_DAO
{
    public class Payment
    {
        public int PaymentId { get; set; }
        public string? PaymentDetails { get; set; }
        public int BookingId { get; set; }
        public decimal GrossAmount { get; set; }
    }
}
