﻿using BookMyShow_DAO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Security.Policy;
using System.Text;

namespace BookMyShow_MVC.Controllers
{
    public class AdminRegistartionsController : Controller
    {
        private readonly HttpClient _httpClient;
        public AdminRegistartionsController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<IActionResult> Default()
        {
            var response = await _httpClient.GetAsync("http://localhost:5294/api/AdminRegistartions");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var adminregistration = JsonConvert.DeserializeObject<List<AdminRegistartion>>(jsondata);
                return View(adminregistration);
            }
            return View();
        }


        public async Task<IActionResult> GetAdminRegistartionDetails(int? id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5294/api/AdminRegistartions/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var adminRegistartion = JsonConvert.DeserializeObject<AdminRegistartion>(jsondata);
                return View(adminRegistartion);
            }
            return NotFound();
        }

        public ActionResult AddAdminRegistrationDetails()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddAdminRegistrationDetails(AdminRegistartion adminRegistartion)
        {
            var response = await _httpClient.PostAsJsonAsync("http://localhost:5294/api/AdminRegistartions", adminRegistartion);
            return RedirectToAction(nameof(Default));
        }


        public async Task<IActionResult> UpdateAdminRegistrationDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5294/api/AdminRegistartions/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var adminRegistartion = JsonConvert.DeserializeObject<AdminRegistartion>(jsondata);
                return View(adminRegistartion);
            }
            return NotFound();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateAdminRegistrationDetails(int id, AdminRegistartion adminRegistartion)
        {
            if (id != adminRegistartion.AdminRegistartionId)
            {
                return BadRequest();
            }
            if (ModelState.IsValid)
            {
                var jsondata = JsonConvert.SerializeObject(adminRegistartion);
                var content = new StringContent(jsondata, Encoding.UTF8, "application/json");
                var response = await _httpClient.PutAsync($"http://localhost:5294/api/AdminRegistartions/{id}", content);
                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction(nameof(Default));
                }
            }
            return View(adminRegistartion);
        }
        // GET: AdminsController/Delete/5


        // POST: AdminsController/Delete/5
        public async Task<IActionResult> DeleteAdminRegistrationDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5294/api/AdminRegistartions/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var adminRegistartion = JsonConvert.DeserializeObject<AdminRegistartion>(jsondata);
                return View(adminRegistartion);
            }
            return NotFound();
        }

        [HttpPost, ActionName("DeleteAdminDetails")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var response = await _httpClient.DeleteAsync($"http://localhost:5294/api/AdminRegistartions/{id}");
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Default));
            }
            return View();

        }
    }
}

