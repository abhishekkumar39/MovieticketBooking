﻿using BookMyShow_DAO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
namespace BookMyShow_MVC.Controllers
{
    public class CancellationsController : Controller
    {
        private readonly HttpClient _httpClient;
        public CancellationsController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }
        // GET: AdminsController
        public async Task<IActionResult> Default()
        {
            var response = await _httpClient.GetAsync("http://localhost:5294/api/Cancellations");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var cancellations = JsonConvert.DeserializeObject<List<Cancellation>>(jsondata);
                return View(cancellations);
            }
            return View();
        }
        
       
        // GET: CancellationsController/Details/5
        public ActionResult GetCancellationDetails(int id)
        {
            return View();
        }

        // GET: CancellationsController/Create
        public ActionResult AddCancellationDetails()
        {
            return View();
        }

        // POST: CancellationsController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddCancellationDetails(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: CancellationsController/Edit/5
        public ActionResult UpdateCancellationDetails(int id)
        {
            return View();
        }

        // POST: CancellationsController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UpdateCancellationDetails(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: CancellationsController/Delete/5
        public ActionResult DeleteCancellationDetails(int id)
        {
            return View();
        }

        // POST: CancellationsController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteCancellationDetails(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
