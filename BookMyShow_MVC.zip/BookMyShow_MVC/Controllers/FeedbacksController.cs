﻿using BookMyShow_DAO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
namespace BookMyShow_MVC.Controllers
{
    public class FeedbacksController : Controller
    {
        private readonly HttpClient _httpClient;
        public FeedbacksController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }
        // GET: AdminsController
        public async Task<IActionResult> Default()
        {
            var response = await _httpClient.GetAsync("http://localhost:5294/api/Feedbacks");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var feedbacks = JsonConvert.DeserializeObject<List<Feedback>>(jsondata); ;
                return View(feedbacks);
            }
            return View();
        }

        // GET: FeedbacksController/Details/5
        public ActionResult GetFeedbackDetails(int id)
        {
            return View();
        }

        // GET: FeedbacksController/Create
        public ActionResult AddFeedbackDetails()
        {
            return View();
        }

        // POST: FeedbacksController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddFeedbackDetails(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: FeedbacksController/Edit/5
        public ActionResult UpdateFeedbackDetails(int id)
        {
            return View();
        }

        // POST: FeedbacksController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UpdateFeedbackDetails(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: FeedbacksController/Delete/5
        public ActionResult DeleteFeedbackDetails(int id)
        {
            return View();
        }

        // POST: FeedbacksController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteFeedbackDetails(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
