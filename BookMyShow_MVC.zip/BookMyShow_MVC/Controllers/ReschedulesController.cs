﻿using BookMyShow_DAO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
namespace BookMyShow_MVC.Controllers
{
    public class ReschedulesController : Controller
    {
        private readonly HttpClient _httpClient;
        public ReschedulesController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }
        // GET: AdminsController
        public async Task<IActionResult> Default()
        {
            var response = await _httpClient.GetAsync("http://localhost:5294/api/Reschedules");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var reschedules = JsonConvert.DeserializeObject<List<Reschedule>>(jsondata);
                return View(reschedules);
            }
            return View();
        }

        // GET: ReschedulesController/Details/5
        public ActionResult GetRescheduleDetails(int id)
        {
            return View();
        }

        // GET: ReschedulesController/Create
        public ActionResult AddRescheduleDetails()
        {
            return View();
        }

        // POST: ReschedulesController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddRescheduleDetails(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ReschedulesController/Edit/5
        public ActionResult UpdateRescheduleDetails(int id)
        {
            return View();
        }

        // POST: ReschedulesController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UpdateRescheduleDetails(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ReschedulesController/Delete/5
        public ActionResult DeleteRescheduleDetails(int id)
        {
            return View();
        }

        // POST: ReschedulesController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteRescheduleDetails(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
