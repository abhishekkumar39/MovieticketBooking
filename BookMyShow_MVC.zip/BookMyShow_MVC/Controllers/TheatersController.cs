﻿using BookMyShow_DAO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
namespace BookMyShow_MVC.Controllers
{
    public class TheatersController : Controller
    {
        private readonly HttpClient _httpClient;
        public TheatersController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }
        // GET: AdminsController
        public async Task<IActionResult> Default()
        {
            var response = await _httpClient.GetAsync("http://localhost:5294/api/Theaters");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var theaters = JsonConvert.DeserializeObject<List<Theater>>(jsondata);
                return View(theaters);
            }
            return View();
        }
        // GET: TheatersController/Details/5
        public ActionResult GetTheaterDetails(int id)
        {
            return View();
        }

        // GET: TheatersController/Create
        public ActionResult AddTheaterDetails()
        {
            return View();
        }

        // POST: TheatersController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddTheaterDetails(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: TheatersController/Edit/5
        public ActionResult UpdateTheaterDetails(int id)
        {
            return View();
        }

        // POST: TheatersController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UpdateTheaterDetails(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: TheatersController/Delete/5
        public ActionResult DeleteTheaterDetails(int id)
        {
            return View();
        }

        // POST: TheatersController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteTheaterDetails(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
