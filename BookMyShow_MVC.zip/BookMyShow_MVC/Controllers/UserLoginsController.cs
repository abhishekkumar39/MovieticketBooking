﻿using BookMyShow_DAO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
namespace BookMyShow_MVC.Controllers

{
    public class UserLoginsController : Controller
    {
        private readonly HttpClient _httpClient;
        public UserLoginsController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }
        // GET: AdminsController
        public async Task<IActionResult> Default()
        {
            var response = await _httpClient.GetAsync("http://localhost:5294/api/UserLogins");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var userLogins = JsonConvert.DeserializeObject<List<UserLogin>>(jsondata);
                return View(userLogins);
            }
            return View();
        }

        // GET: UserLoginsController/Details/5
        public ActionResult GetUserLoginDetails(int id)
        {
            return View();
        }

        // GET: UserLoginsController/Create
        public ActionResult AddUserLoginDetails()
        {
            return View();
        }

        // POST: UserLoginsController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddUserLoginDetails(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: UserLoginsController/Edit/5
        public ActionResult UpdateUserLoginDetails(int id)
        {
            return View();
        }

        // POST: UserLoginsController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UpdateUserLoginDetails(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: UserLoginsController/Delete/5
        public ActionResult DeleteUserLoginDetails(int id)
        {
            return View();
        }

        // POST: UserLoginsController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteUserLoginDetails(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
