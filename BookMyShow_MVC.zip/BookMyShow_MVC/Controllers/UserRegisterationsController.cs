﻿using BookMyShow_DAO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Security.Policy;
using System.Text;

namespace Online_Food_Delivery_MVC.Controllers
{
    public class UserRegistrationsController : Controller
    {
        private readonly HttpClient _httpClient;
        public UserRegistrationsController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<IActionResult> Default()
        {
            var response = await _httpClient.GetAsync("http://localhost:5012/api/UserRegistrations");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var userRegistrations = JsonConvert.DeserializeObject<List<UserRegistration>>(jsondata);
                return View(userRegistrations);
            }
            return View();
        }

        // GET: AdminsController/Details/5


        public async Task<IActionResult> GetUserRegistrationDetails(int? id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5012/api/UserRegistrations/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var userRegistration = JsonConvert.DeserializeObject<UserRegistration>(jsondata);
                return View(userRegistration);
            }
            return NotFound();
        }
        // GET: AdminsController/Create
        public ActionResult AddAdminDetails()
        {
            return View();
        }

        // POST: AdminsController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddAdminDetails(Admin admin)
        {
            var response = await _httpClient.PostAsJsonAsync("http://localhost:5012/api/Admins", admin);
            return RedirectToAction(nameof(Default));
        }

        // GET: AdminsController/Edit/5
        public async Task<IActionResult> UpdateAdminDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5012/api/Admins/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var admin = JsonConvert.DeserializeObject<Admin>(jsondata);
                return View(admin);
            }
            return NotFound();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateAdminDetails(int id, Admin admin)
        {
            if (id != admin.AdminId)
            {
                return BadRequest();
            }
            if (ModelState.IsValid)
            {
                var jsondata = JsonConvert.SerializeObject(admin);
                var content = new StringContent(jsondata, Encoding.UTF8, "application/json");
                var response = await _httpClient.PutAsync($"http://localhost:5012/api/Admins/{id}", content);
                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction(nameof(Default));
                }
            }
            return View(admin);
        }
        // GET: AdminsController/Delete/5


        // POST: AdminsController/Delete/5
        public async Task<IActionResult> DeleteAdminDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5012/api/Admins/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var user = JsonConvert.DeserializeObject<Admin>(jsondata);
                return View(user);
            }
            return NotFound();
        }

        [HttpPost, ActionName("DeleteAdminDetails")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var response = await _httpClient.DeleteAsync($"http://localhost:5012/api/Admins/{id}");
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Default));
            }
            return View();

        }
    }
}

